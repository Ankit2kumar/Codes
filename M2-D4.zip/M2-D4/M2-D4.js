const submitBtn = document.querySelector('#submit');
			let teams = [];
			const teamMember = {
				firstName: firstName,
				lastName: lastName,
				teamName: teamName,
			};
			const home = document.querySelector('#home');
			submitBtn.onclick = function () {
				const firstName = document.querySelector('#firstName').value;
				const lastName = document.querySelector('#lastName').value;
				const teamName = document.querySelector('#teamName').value;
				const numberOfTeams = document.querySelector('#numberOfTeams').value;
				//if(numberOfTeams > 1){
				//	for(let i=0;i<numberOfTeams;i++){
						//const ol = document.createElement('ol');
						let teams= document.querySelector('#teams')
						const li1 = document.createElement('li');
					li1.innerText = firstName
					const li2 = document.createElement('li');
					li2.innerText = lastName
					const li3 = document.createElement('li');
					li3.innerText = teamName
					teams.appendChild(li1);
					teams.appendChild(li2);
					teams.appendChild(li3);
					
					//teams.appendChild(ol)
					}
				//}
				/*else{
					const ol = document.createElement('ol');
					const li = document.createElement('li');
					li.innerText = firstName + ' ' + lastName + ': ' + teamName;
					ol.appendChild(li);
					const teams= document.querySelector('.teams')
					teams.appendChild(ol)
				}*/

				
				


			
